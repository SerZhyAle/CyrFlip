# Smart Log Analyst (log-reader)

This skill reads and analyzes application logs (server logs, Android logcat, error dumps) of any size without overloading the agent's context window.

## Usage

```text
/log-reader [filter] [path]
```

Examples:
- `/log-reader` — analyze default log (e.g. `logs/app.log` or `logs/current.log`).
- `/log-reader errors` — show errors and exceptions.
- `/log-reader "db connection" custom.log` — search for a specific term in a custom file.

---

## Log Resolution Protocol

**Step 1 — Locate target log.**
Find log files in common directories (e.g., `logs/`, `temp/`, `storage/logs/`, `build/`). If multiple exist, sort by last modified time.

**Step 2 — Check file size and line count. MANDATORY.**
Before opening the file, run a quick size check (e.g. checking file metadata or running `wc -l` or equivalent shell commands). Never read a large file linearly.

Choose a reading strategy based on file size:
* **< 1 MB (Small):** Read the whole file.
* **1 MB – 10 MB (Medium):** Read the last 500 lines (where errors usually are) and the first 100 lines (where configuration/startup info resides).
* **> 10 MB (Large):** Do **NOT** read directly. Use `grep` or search utilities to extract lines matching the filter.

---

## Analysis Modes

The skill extracts information based on requested modes:

1. **Auto-summary (Default):**
   - Count warnings vs errors.
   - List the top 3 repeating error messages.
   - Extract the primary crash trace if present.

2. **Errors & Exceptions:**
   - Filter lines containing `Error`, `Exception`, `Fatal`, `Crash`, or `E/` logging prefix.
   - Clean up stack traces to show the file name and line number where the error originated.

3. **Flow Tracing:**
   - Follow a specific identifier (like `requestId`, `userId`, or class name) across multiple log lines to construct a chronological event timeline.

4. **Noise Detection:**
   - Identify repeating spam lines (e.g. connection polls, resource cleanups) and group/collapse them.
