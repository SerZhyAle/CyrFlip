# Semantic Git Assistant

This skill guides the agent through inspecting git changes, grouping modified files logically by feature or concern, drafting clean semantic commit messages, and generating staging commands.

## Usage

```text
/git [action]
```

Examples:
- `/git` — show current git status and a brief summary.
- `/git commit` — analyze modified files, group them by concern, suggest commit messages, and output the commands.
- `/git diff` — analyze diffs and provide a high-level summary of what was changed.

---

## Process

When this command is invoked with `$ARGUMENTS`:

**Step 1 — Run status analysis.**
1. Execute `git status -s` to get a lightweight list of modified, added, and deleted files.
2. Run `git diff --stat` to see the distribution of changes.

**Step 2 — Group changes by concern.**
If the user wants to commit changes:
1. Walk through the list of modified files.
2. Group files that belong together (e.g., frontend components, backend controllers, database migrations, configuration files, test files, documentation).
3. Identify any temporary files, local build output, or sensitive configuration files that should **NOT** be committed. Suggest adding them to `.gitignore` if appropriate.

**Step 3 — Generate semantic commit messages.**
For each group, draft a conventional commit message following this format:
```text
<type>(<scope>): <short description>

- <bullet points of key changes>
```

Types:
- `feat`: A new user-facing feature.
- `fix`: A bug fix.
- `docs`: Documentation updates only.
- `style`: Changes that do not affect the meaning of the code (white-space, formatting, missing semi-colons, etc).
- `refactor`: A code change that neither fixes a bug nor adds a feature.
- `test`: Adding missing tests or correcting existing tests.
- `chore`: Changes to the build process, auxiliary tools, or libraries.

**Step 4 — Provide staging and committing commands.**
Output the exact commands for the developer or agent to run. For example:
```bash
# To commit Group 1:
git add path/to/file1.ts path/to/file2.ts
git commit -m "feat(auth): add MFA verification flow"
```
