# Smart Documentation Assistant (doc-update)

This skill scans recent code changes, detects affected areas, and updates relevant documentation files (changelogs, architecture docs, READMEs, string files) to ensure project documentation remains in sync with the codebase.

## Usage

```text
/doc-update [description]
```

Examples:
- `/doc-update Added oauth authentication`
- `/doc-update` — auto-infer the changes by comparing HEAD changes or staging files.

---

## Process

When this command is invoked with `$ARGUMENTS`:

**Step 1 — Identify scope of changes.**
1. If description arguments are provided, use them.
2. Otherwise, check git changes:
   - For staged changes: `git diff --name-only --cached`
   - For recent commit: `git diff --name-only HEAD~1 HEAD`
3. Read the file names and a summary of diffs to determine what logic has changed.

**Step 2 — Evaluate documentation checklist.**
Walk through the checklist of project documentation files:

### Checklist

#### A. Changelog / Release Notes (Every code change)
- **Path:** `CHANGELOG.md` or `dev/CHANGELOG.md`
- **Action:** Add a entry detailing the changed files, features added, or bugs fixed. Keep entries structured (e.g. Added, Fixed, Changed, Security).

#### B. User-Facing documentation
- **Path:** `README.md`
- **Action:** If a user-facing feature or configuration option was added/modified, update the usage instructions or options table in the README.

#### C. Localization resources
- **Path:** `src/locales/` or `res/values/`
- **Action:** Check if new localized strings were added. Ensure translation files for other languages have corresponding placeholder keys.

#### D. Architecture & Developer guides
- **Path:** `docs/ARCHITECTURE.md` or design documents.
- **Action:** If the structure of modules, database schemas, or dependency trees changed, update the architecture text/mermaid diagrams.

**Step 3 — Apply updates.**
Make edits to the affected documentation files.

**Step 4 — Print summary.**
Output a markdown summary table listing each document checked, its status (Updated / Skipped), and the reason for the decision.
