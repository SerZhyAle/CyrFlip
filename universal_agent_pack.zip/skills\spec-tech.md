# Tactical Specification Writer (spec-tech)

This skill breaks down an **approved strategic spec** (`spec_<short-name>.md`, `Status: Approved`) into a sequenced, phase-based technical implementation plan. The tactical spec is written in English, targetted at a developer, and contains precise code details (files, classes, functions, SQL, API endpoints, step-by-step changes).

## Usage

```text
/spec-tech <short-name>
```

This command generates a folder containing tactical checklists:
```text
docs/specs/spec_<short-name>/
  INDEX.md                           # Overview of phases, blockers, and completion gate
  PHASE_01__<slug>.md                # Scaffolding, schemas, interfaces
  PHASE_02__<slug>.md                # Implementation
  ...
  PHASE_NN__docs-and-cleanup.md      # Final verification, changelogs, docs update
```

---

## Technical Design Principles

1. **English & Technical:** Body language is English. Imperative, dry, concise.
2. **Foundations First:** Set up data models, database schemas, API contracts, interfaces, and DI bindings in early phases before implementing components that consume them.
3. **Coherent Phases:** Each phase must leave the codebase in a compilable state. A developer should be able to commit/merge a single phase safely to main.
4. **Step Verification:** Every single step must contain a machine-verifiable or clear manual verification instruction (e.g. run a test, run a grep check, check UI).
5. **Phase Done Criteria:** Explicit checkpoints that prove the entire phase's goals are fully achieved.

---

## Process

When this command is invoked with `$ARGUMENTS`:

**Step 1 — Parse arguments and read strategic spec.**
Load `docs/specs/spec_<short-name>.md`. Confirm it is approved. If it is in `Draft` state, abort and request user approval.

**Step 2 — Design the phase graph.**
Divide the implementation into 3–8 logical phases. Give each phase a slug name (e.g. `schema-setup`, `backend-api`, `frontend-ui`, `cleanup-docs`).

**Step 3 — Write `INDEX.md`** using the template below.

**Step 4 — Write each phase file `PHASE_NN__<slug>.md`** using the template below.

**Step 5 — Update status.**
Change the strategic spec status to `Tactical` and add a link to the `INDEX.md`.

---

## Templates

### 1. INDEX.md Template

```markdown
# Tactical Spec: <Feature Name> (INDEX)

**Strategic spec:** [spec_<short-name>.md](../spec_<short-name>.md)
**Status:** In Progress
**Target Branch:** `main`

## Phase Overview

- [ ] [Phase 01: Foundations](PHASE_01__foundations.md) (Status: Pending)
- [ ] [Phase 02: Implementation](PHASE_02__implementation.md) (Status: Pending)
- [ ] [Phase 03: Cleanup & Docs](PHASE_03__cleanup.md) (Status: Pending)

## Pre-Implementation Blockers
* [ ] Verify all open research items in strategic spec are closed.

## Completion Gate
* [ ] All phase checklist items are complete.
* [ ] Project compiles warning-free.
* [ ] All automated tests pass.
```

### 2. Phase Template (`PHASE_NN__<slug>.md`)

```markdown
# Phase <NN>: <Slug Name>

## Files Touched

| Action | Path | Description | Line Budget |
|--------|------|-------------|-------------|
| [NEW]  | `src/core/Auth.ts` | Auth provider | +50 lines |
| [MODIFY] | `src/index.ts` | Initialize Auth | +10 lines |

## Steps

### Step <NN>.1: [Short Title]
* **Description:** [What to do, detail instructions]
* **Code/Grep Check:**
  ```bash
  # Command or grep to verify existence
  grep -n "class AuthProvider" src/core/Auth.ts
  ```
* **Depends on:** [None or prior Step]

### Step <NN>.2: [Short Title]
* **Description:** [Step details]
* **Verification:** Run `npm run test -- --grep Auth`

## Phase Done Criteria
- [ ] Core classes compile successfully.
- [ ] All tests related to this phase pass.
```
