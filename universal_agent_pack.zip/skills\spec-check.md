# Specification Audit & Verifier (spec-check)

This skill audits the current state of the repository against the strategic and tactical specifications for a feature, verifying that every requirement, file constraint, class structure, and test step has been implemented correctly.

## Usage

```text
/spec-check <short-name> [options]
```

Options:
- `--strategic` — audit strategic spec goals and constraints only.
- `--tactical` — audit tactical phases and steps only.
- `--phase <NN>` — audit a specific phase only.

The skill writes an audit report to: `docs/specs/spec_<short-name>__audit_<YYYY-MM-DD>.md`.

---

## Audit Checklist

When auditing, the skill checks the following:

### 1. Strategic Audit
- **Goals Met:** Verify that all qualitative goals outlined in the strategic spec have been addressed in the code.
- **Constraints Maintained:** Verify all system and platform constraints (e.g. min/max limits, performance thresholds, target versions) are met.
- **Closed Research:** Check if all open research items are marked as closed or resolved.
- **User-Facing Documentation:** Check if new features are documented in user-facing documentation (e.g. `docs/FEATURES.md` or similar).

### 2. Tactical Audit
- **Files Touched:** Check that every file listed in the tactical phase's "Files Touched" table actually exists or has been modified.
- **Steps Verification:** Read each step's `Verification` or `Code/Grep Check` section. Execute the verification commands (like `grep` or `run test`) and assert they pass.
- **Phase Status:** Cross-check the phase checklists inside the files against the actual file contents. Assert that checked items are actually completed.

---

## Process

When this command is invoked with `$ARGUMENTS`:

**Step 1 — Parse arguments and locate files.**
Locate `docs/specs/spec_<short-name>.md` and the folder `docs/specs/spec_<short-name>/`. Abort if the spec files do not exist.

**Step 2 — Extract Verification Rules.**
Parse the files to extract goals, constraints, file listings, verification script commands, and checkboxes.

**Step 3 — Run Checks.**
Run checks on the repository:
1. Run `glob` to verify file existence.
2. Run `grep` to verify class/method declarations.
3. Run tests using build tools.
4. Run grep to search for forbidden calls (e.g., printing debugging logs in production).

**Step 4 — Generate the Audit Report.**
Write the results to `docs/specs/spec_<short-name>__audit_<YYYY-MM-DD>.md`. The report must list:
- **Outcome:** `PASS` (fully verified), `PARTIAL` (minor warning/gaps), `FAIL` (broken requirements/failing steps).
- **Findings:** A table listing each check, its outcome, and a clickable file reference.
- **Action Items:** Concrete tasks to fix any warning or failure.
