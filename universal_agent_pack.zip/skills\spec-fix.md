# Specification Audit Fixer (spec-fix)

This skill consumes the latest `/spec-check` audit report and applies **mechanical, trivial** fixes to the repository so the next audit can pass. It acts defensively, skipping any issues that require architectural decisions, design judgement, or non-trivial code logic.

## Usage

```text
/spec-fix <short-name> [options]
```

Options:
- `--only FAIL` — resolve hard failures only, skipping warnings.
- `--dry-run` — preview planned changes without applying them.

---

## Auto-Fixable Categories

The skill can automatically fix the following issues:

| Issue | Auto Fix |
|-------|----------|
| Missing Changelog / Dev Log entry | Run build-in changelog command or append a line to the changelog file. |
| Missing localization key in translation file | Copy the key from the source translation file and append it to target files with a `TODO Translate` comment. |
| Stale components / API catalog | Run registration / index scanning scripts to rebuild catalog indexes. |
| INDEX phase status drift | Recompute phase counter and update status (e.g. changing `Pending` -> `Done` in `INDEX.md` if the phase file itself is completed). |
| Stale spec header pointers | Insert pointers to audit files into the strategic spec headers. |

What the skill **NEVER** does:
- Implement class methods, write business logic, or change control flows.
- Make up translation strings.
- Perform database schema migrations.
- Rename files or core identifiers.

---

## Process

When this command is invoked with `$ARGUMENTS`:

**Step 1 — Locate target audit report.**
Find the latest audit file `docs/specs/spec_<short-name>__audit_*.md`. If none exists, abort and tell the user to run `/spec-check` first.

**Step 2 — Parse Action Items.**
Scan the report's "Action Items" section. Classify each item as:
- `auto`: Maps to a fix in the auto-fixable table.
- `manual`: Requires developer intervention (e.g., write logic, fix test failures).
- `skipped`: Excluded by options.

**Step 3 — Dry-run preview.**
Print a table of planned actions in the chat console:
```text
| ID | Check | Classification | Action | File |
|----|-------|----------------|--------|------|
| 1  | 2.3   | auto           | Update INDEX status | INDEX.md |
| 2  | 3.1   | manual         | Follow-up (code logic needed) | Controller.ts |
```

If `--dry-run` is specified, exit. Otherwise, proceed.

**Step 4 — Execute Auto Fixes.**
Apply changes in order (Changelogs last, catalog scanning first).

**Step 5 — Report Follow-ups.**
Provide a list of manual action items that the developer must complete.
