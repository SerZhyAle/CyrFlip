# Smart Build & Test Assistant

This skill automatically detects the project's build system, languages, and testing frameworks, and helps the agent compile, test, lint, and run the code.

## Usage

```text
/build [action] [arguments]
```

Examples:
- `/build` — auto-detect setup, run default compilation/build.
- `/build test` — run unit or integration tests.
- `/build lint` — run static analysis / linters.
- `/build run` — run the application locally in development mode.
- `/build clean` — clean build artifacts.

---

## Process

When this command is invoked with `$ARGUMENTS`:

**Step 1 — Auto-detect build system.**
Scan the project root for signature files to identify the technology stack:

| File | Ecosystem | Build Cmd | Test Cmd | Lint Cmd |
|------|-----------|-----------|----------|----------|
| `package.json` | Node.js / JS / TS | `npm run build` | `npm test` | `npm run lint` |
| `Cargo.toml` | Rust | `cargo build` | `cargo test` | `cargo clippy` |
| `build.gradle`/`build.gradle.kts` | JVM / Kotlin / Android | `./gradlew assembleDebug` | `./gradlew test` | `./gradlew lint` |
| `pom.xml` | Java (Maven) | `mvn clean package` | `mvn test` | `mvn checkstyle:check` |
| `*.sln` / `*.csproj` | .NET / C# | `dotnet build` | `dotnet test` | `dotnet format` |
| `go.mod` | Go | `go build ./...` | `go test ./...` | `go vet ./...` |
| `Makefile` | C/C++/Generic | `make` | `make test` | `make lint` |
| `pyproject.toml`/`requirements.txt` | Python | `pip install -e .` | `pytest` | `flake8` or `black --check` |

If multiple build files are detected, prompt the user or choose the primary one based on recent file modifications.

**Step 2 — Execute the requested action.**
Map the requested action (`test`, `lint`, `run`, `clean`, or default compile) to the detected system's commands:
1. Run the command using the shell tool.
2. Capture the output.

**Step 3 — Diagnose failures.**
If the command fails (non-zero exit code):
1. Extract the compilation errors, lint failures, or failing test traces from the console output.
2. Group the errors by file and line.
3. Suggest concrete code modifications to resolve the errors.
4. Offer to automatically apply trivial fixes (like imports or basic syntax corrections) or present a plan for larger fixes.
